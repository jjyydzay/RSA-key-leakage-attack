from sage.all import *
import itertools

# display matrix picture with 0 and X
# references: https://github.com/mimoo/RSA-and-LLL-attacks/blob/master/boneh_durfee.sage
def matrix_overview(BB):
    for ii in range(BB.dimensions()[0]):
        a = ('%02d ' % ii)
        for jj in range(BB.dimensions()[1]):
            a += ' ' if BB[ii,jj] == 0 else 'X'
            if BB.dimensions()[0] < 60:
                a += ' '
        print (a)

def sort_monomials(monomials):
    x, y, z = monomials[0].parent().gens()
    Mx = []
    My = []
    Mz = []
    degx = max([monomial.degree(x) for monomial in monomials])
    degy = max([monomial.degree(y) for monomial in monomials])
    degz = max([monomial.degree(z) for monomial in monomials])
    for i in range(degx + 1):
        for j in range(degy + 1):
            for k in range(degz + 1):
                if k+j > i:
                    break
                mono = x^i * y^j * z^k
                if mono in monomials:
                    Mx += [mono]
    for j in range(degy + 1):
        for k in range(degz + 1):
            for i in range(degx + 1):
                if k > j:
                    break
                mono = x^i * y^j * z^k
                if mono in monomials and mono not in Mx:
                    My += [mono]
    for k in range(degz + 1):
        for j in range(degy + 1):
            for i in range(degx + 1):
                mono = x^i * y^j * z^k
                if mono in monomials and mono not in (Mx+My):
                    Mz += [mono]
    return Mx + My + Mz


def jochemsz_may_trivariate(pol, XX, YY, ZZ, WW, tau, mm):
    '''
    Implementation of Finding roots of trivariate polynomial [1].
    Thanks @Bono_iPad

    References: 
    [1] Ellen Jochemsz and Alexander May. "A Strategy for Finding Roots of Multivariate Polynomials with New Applications in Attacking RSA Variants"
    '''
    tt = floor(mm * tau)
    cond = XX^(7 + 9*tau + 3*tau^2) * (YY*ZZ)^(5+9/2*tau) < WW^(3 + 3*tau)
    bound_1 = (XX) ** (1 + 3 * tau) * (YY) ** (2 + 3 * tau) * (ZZ) ** (1 + 3 * tau + 3 * tau ** 2) > (WW) ** (1 + 3 * tau)
    bound_2 = (XX) ** (2 + 3 * tau) * (YY) ** (3 + 6 * tau + 3 * tau ** 2) * (ZZ) ** (3 + 3 * tau) > (WW) ** (2 + 3 * tau)
    
    print ('[+] Bound check: X^{7+9tau+3tau^2} * (YZ)^{5+9/2tau} < W^{3+3tau}:'), 
    if cond:
        print ('OK')
    else:
        print ('NG')
    
    print ('[+] Bound check: Bound of Ernst 1:'), 
    if bound_1:
        print ('OK')
    else:
        print ('NG')
    
    print ('[+] Bound check: Bound of Ernst 2:'), 
    if bound_2:
        print ('OK')
    else:
        print ('NG')

    RR = WW * XX^(2*(mm-1)+tt) * (YY*ZZ)^(mm-1)
    # Polynomial constant coefficient (a_0) must be 1
    # XXX: can a_0 be zero?
    f_ = pol
    a0 = f_.constant_coefficient()

    if a0 != 0:
        F = Zmod(RR)
        PK = PolynomialRing(F, 'xs, ys, zs')
        f_ = PR(PK(f_) * F(a0)^-1)

    # Construct set `S` (cf.[1] p.8)
    S = set()
    for i2, i3 in itertools.product(range(0, mm), repeat=2):
        for i1 in range(0, 2*(mm-1) - (i2 + i3) + tt + 1):
            S.add(x^i1 * y^i2 * z^i3)
    m_S = []
    for k in range(mm):
        for j in range(mm):
            for i in range(2*(mm-1) - (i2 + i3) + tt + 1):
                m_S += [x^i*y^j*z^k]
    S = m_S

    # Construct set `M` (cf.[1] p.8)
    M = set()
    for i2, i3 in itertools.product(range(0, mm + 1), repeat=2):
        for i1 in range(0, 2*mm - (i2 + i3) + tt + 1):
            M.add(x^i1 * y^i2 * z^i3)
    M_S = list(M - set(S))

    m_M_S = []
    deg_x = max([mono.degree(x) for mono in M_S])
    deg_y = max([mono.degree(y) for mono in M_S])
    deg_z = max([mono.degree(z) for mono in M_S])
    for k in range(deg_z + 1):
        for j in range(deg_y + 1):
            for i in range(deg_x + 1):
                mono = x^i*y^j*z^k
                if mono in M_S:
                    m_M_S += [mono]
    M_S = m_M_S

    # Construct polynomial `g`, `g'` for basis of lattice
    g = []
    g_ = []
    M_S = sort_monomials(M_S)
    S = sort_monomials(S)
    for monomial in S:
        i1 = monomial.degree(x)
        i2 = monomial.degree(y)
        i3 = monomial.degree(z)
        g += [monomial * f_ * XX^(2*(mm-1)+tt-i1) * YY^(mm-1-i2) * ZZ^(mm-1-i3)]

    for monomial in M_S:
        g_ += [monomial * RR]

    # Construct Lattice from `g`, `g'`
    monomials_G = []
    monomials = []
    G = g + g_
    deg_x = deg_y = deg_z = 0
    for g_poly in G:
        monomials_G += g_poly.monomials()
        deg_x = max(deg_x, g_poly.degree(x))
        deg_y = max(deg_y, g_poly.degree(y))
        deg_z = max(deg_z, g_poly.degree(z))
    monomials_G = sorted(set(monomials_G))

    for k in range(deg_z + 1):
        for j in range(deg_y + 1):
            for i in range(deg_x + 1):
                mono = x^i*y^j*z^k
                if mono in monomials_G:
                    monomials += [x^i*y^j*z^k]
    assert len(monomials) == len(G)
    monomials = sort_monomials(monomials)
    dims = len(monomials)
    M = Matrix(IntegerRing(), dims)
    for i in range(dims):
        M[i, 0] = G[i](0, 0, 0)
        for j in range(dims):
            if monomials[j] in G[i].monomials():
                M[i, j] = G[i].monomial_coefficient(monomials[j]) * monomials[j](XX, YY, ZZ)
    matrix_overview(M)
    print ()
    print ('=' * 128)
    print ()

    # LLL

    B = M.LLL()
    matrix_overview(B)

    # Re-construct polynomial `H_i` from Reduced-lattice
    H = [(i, 0) for i in range(dims)]
    H = dict(H)
    for i in range(dims):
        for j in range(dims):
            H[i] += PR((monomials[j] * B[i, j]) / monomials[j](XX, YY, ZZ))

    PX = PolynomialRing(IntegerRing(), 'xn')
    xn = PX.gen()
    PY = PolynomialRing(IntegerRing(), 'yn')
    yn = PX.gen()
    PZ = PolynomialRing(IntegerRing(), 'zn')
    zn = PX.gen()

    # Solve for `x`
    r1 = H[2].resultant(pol, y)
    r2 = H[3].resultant(pol, y)
    r3 = r1.resultant(r2, z)
    x_roots = [t[0] for t in r3.subs(x=xn).roots()]
    assert len(x_roots) > 0
    if len(x_roots) == 1 and x_roots[0] == 0:
        print ('[-] Can\'t find non-trivial solution for `x`')
        return (0, 0, 0)
    x_root = x_roots[0]
    print ('[+] Found x0 = %d' % x_root)

    # Solve for `z`
    r1_ = r1.subs(x=x_root)
    r2_ = r2.subs(x=x_root)
    z_roots = [t[0] for t in gcd(r1_, r2_).subs(z=zn).roots()]
    assert len(z_roots) > 0
    if len(z_roots) == 1 and z_roots[0] == 0:
        print ('[-] Can\'t find non-trivial solution for `z`')
        return 0, 0, 0
    z_root = z_roots[0]
    print ('[+] Found z0 = %d' % z_root)

    # Solve for `y`
    y_roots = [t[0] for t in H[2].subs(x=x_root, z=z_root).subs(y=yn).roots()]
    assert len(y_roots) > 0
    if len(y_roots) == 1 and y_roots[0] == 0:
        print ('[-] Can\'t find non-trivial solution for `y`')
        return (0, 0, 0)
    y_root = y_roots[0]
    print ('[+] Found y0 = %d' % y_root)
    assert pol(x_root, y_root, z_root) == 0
    return (x_root, y_root, z_root)


def original_test():
    # Sample Implementation: small secret exponents attack for Common Prime RSA proposed at [1]

    # PlaidCTF 2017: Common
    n = 58088432169707511884530887899705328460043341752051203523596713643978064163990486003388043207708974302843002172264417411586749486956628013574926573715095249317804208372132481594468281365459316852927039797580064466731086129431102303726096683810636192790138689214881951836298576801818592777778548978736174404573637727968467102304994883348510912250960513170991711142297420921866513951251779528983034404550484931629702384165892697556071097115581299228167852394258387798734409094231193145682416393190929132395057494573898497863918989076392413537702062176268786330410635086565380004463707094857932051066439903977555824218219175469965671350998705376046031482320586719742092257095632485346554447599297796154806971819544073874759609887168714861438380508381072200369356855424637087904990126639040356052220595703217836390163784968964557550834138598331720685971193948909145336792118311346853933919997080542485529346554810899612986872128053464963893904969598870571593590391792680177336466285483108769678524923709955832516312592396932275858180384073997491565078915852990631405792518132787289319255490058314797418779789436482247156880548274241414788581503832731423362447015575598719157544932430682335826661205441977262084135022109705809490179219483
    e = 1296863142627338816011174237898978985407338763709131570002553514972553044428195580769854555546152719732990573444787592853632636242677007643888487629752955065888264014132275294946697123213980215879592216819850992977582758776020797257958443371755687921634978634111557036569863976062810460472490135115734285081745257140890782551910267112228842110620084653440977034007333330590567591507504424149155838966172077983891168269103390479149309815192817914537419492632845858394205854892694802909512194639800529863998537677351955149803841057222279150345376221210193853988829004456607875070080035867353641697190133291884195010172677474092272163240020759433657106746641878734177642792083528380007586872967990567342937466301144028345682953828338178443155

    gamma = 0.4
    delta = 0.1604

    PR = PolynomialRing(ZZ, 'x, y, z')
    x, y, z = PR.gens()

    # Maximal value of solution `x0`, `y0`, `z0`
    XX = floor(n^delta)
    YY = floor(n^(delta + 0.5 - gamma))
    ZZ = YY

    # Norm of polynomial as vector representation
    WW = floor(n^(2 + 2*delta - 2*gamma))

    # Some Non-negative real (cf. [1] p.13)
    tau = (1/2 + gamma - 4*delta) / (2*delta)

    # Powering degree
    mm = 1

    # Target polynomial
    pol = e^2 * x^2 + e*x*(y+z-2)-(y+z-1)-(n-1)*y*z
    x0, y0, z0 = jochemsz_may_trivariate(pol, XX, YY, ZZ, WW, tau, mm)

    # `x0` is secret exponents. so, `e` * `x0` equivalent to 1 modulo `\phi(n)`.
    assert (Mod(0xdeadbeefcafebabe, n)^e)^x0 == 0xdeadbeefcafebabe

    print ('[+] d = %d' % x0)
  
def find_tau(mm, XX, YY, ZZ, WW, tau_min=0, tau_max=10, step=0.01):
    valid_taus = []
    
    # 遍历 tau 的值
    tau = tau_min
    while tau <= tau_max:
        # 计算 tt
        tt = floor(mm * tau)

        # 计算条件 cond
        left_side = XX^(7 + 9*tau + 3*tau^2) * (YY*ZZ)^(5+9/2*tau)
        right_side =  WW^(3 + 3*tau)

        # 检查不等式是否成立
        if left_side < right_side:
            valid_taus.append(tau)

        # 递增 tau
        tau += step
    
    return valid_taus

if __name__ == '__main__':

    PR = PolynomialRing(ZZ, 'x, y, z')
    x, y, z = PR.gens()

    f = y*z + 3570933230773454036103400438523094494860730146879558128058270144959251135492234076661103748194173734451656482351563013457204873521151688759417651289937071689065482923*x - 104127387110649935781881558935441231540227539505240701848523964154275063736434925252998362295439014810169607552232082698840729377535733554222490283737099809463337808089871332785652273964313621623546993321809484060172177294526141218235332043161318907448668404673501865142995613180639962922703575258020054685601*y + 2398428289575168743969377983353216064304120262368095024071625479122188048749343007751271886109708619848818114171215288898080933374069012086844688430904110968157022521*z + 87900612800094814187785417775809906741585307871975334805870527242763747118276970991486269237448311839656405023940671563014070199362059448795235348997647458329370087193741521123202075300216458701779430048680440967714222817846898593146706840092815919141340310581837289352407558988586075818330383283452799988774
    m = 1
    t = 1
    X = 26959946667150639794667015087019630673637144422540572481103610249217
    Y = 1399778233037
    Z = 30612848348297310753218086319352795409603253593603978790490533790909670862976701122527715405557736827609853225578260365970295245274833961617694066691014657
    n = 235703182760991028100835628197189395592026797233381765711759412785764141416457505226841687081228951718305707358958562320738936522076600110753275777444076204050379752207953072187288955559109338931365303437476671497676934343926845187183650547549280812206543481858378165653130298610130695172997023381837493601824383845805301884937646416849718992342632605196436826903219963504148091185075123216025114764995471257015284973906588270233987619747463705608765592076133277750075045657273185994801267574551694480347173074385701578628430993299475991406407930894406790494058947157
    W = 145755249940401128526309039670085024282399458002031715295395373468573350822503159684640782834911389152875848222932985797973502293676425266479653546181195858049763268430813360495290675782482308196754491882912971719974617435260720909372861549401102667771795078364955445280312758889895559183630564822671159935662660291714637
    
    tau_list = find_tau(m, X, Y, Z, W, tau_min=0, tau_max=10, step=0.01)
    if len(tau_list) > 0:
        tau = tau_list[0]
    else:
        tau = 1
    
    print("tau =",tau)

    x0, y0, z0 = jochemsz_may_trivariate(f, X, Y, Z, W, tau, m)
    print (x0, y0, z0)
