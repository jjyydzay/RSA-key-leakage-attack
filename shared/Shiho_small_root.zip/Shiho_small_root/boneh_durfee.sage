from sage.rings.finite_rings.integer_mod_ring import is_IntegerModRing
from sage.all import *
from copy import copy
import itertools
import sys

# display matrix picture with 0 and X
# references: https://github.com/mimoo/RSA-and-LLL-attacks/blob/master/boneh_durfee.sage
def matrix_overview(BB, bound=None):
    for ii in range(BB.dimensions()[0]):
        a = ('%02d ' % ii)
        for jj in range(BB.dimensions()[1]):
            a += ' ' if BB[ii,jj] == 0 else 'X'
            if BB.dimensions()[0] < 60:
                a += ' '
        if bound is not None and BB[ii,ii] > bound:
            a += '~'
        print (a)
    print() 

def boneh_durfee_bivariate(_pol, modulo, XX, YY, mm, tt):
    '''
    Implementaion of Boneh-Durfee's Solving Bivariate Modular Equation with Small Root [1].

    References:
    [1] Dan Boneh and Glenn Durfee. 1999. "Cryptanalysis of RSA with Private Key d Less than N^0.292"
    '''
    '''
    Lifting `_pol` upto Z[x, y]
    '''
    PR = PolynomialRing(ZZ, 'x, y')
    x, y = PR.gens()
    if is_IntegerModRing(_pol.parent().base_ring()):
        '''
        Case `_pol` belongs to (Z/nZ)[x,y]
        Lifting map `h`:
        h: (Z/nZ)[x,y]  -> Z[x',y']
        f(x, y)   |-> f(x', y')
        This map is not homomorphic but we use homomorphism set feature for simplify, in following codes.
        '''
        h = Hom(_pol.parent(), PR)([x, y], check=False) # lift up map
        f = h(_pol)
    else:
        '''
        Case `_pol` belongs to the ring `R[x,y]`
        (includes Z[x,y] and R is an any ring which has natural map to Z).

        In this case, we use the natural map created by SAGE.
        '''
        f = _pol.parent().hom(PR)(_pol)
    # x-shift
    gik = {}
    # y-shift
    hjk = {}
    for k in range(mm + 1):
        fkmod = f^k * modulo^(mm-k)
        for i in range(mm - k + 1):
            gik[i, k] = x^i * fkmod
        for j in range(1, tt + 1):
            hjk[j, k] = y^j * fkmod

    # set of all monomials
    monomials = reduce(lambda u,v: u.union(set(v.monomials())), gik.values(), set())
    monomials = reduce(lambda u,v: u.union(set(v.monomials())), hjk.values(), monomials)
    degx = max([u.degree(x) for u in monomials])
    degy = max([u.degree(y) for u in monomials])

    # sort monomials
    Mx = []
    My = []
    for i in range(degx + 1):
        for j in range(degy + 1):
            if j > i:
                break
            mono = x^i * y^j
            if mono in monomials:
                Mx += [mono]
    for j in range(1, tt):
        for i in range(degx + 1):
            jj = i + j
            mono = x^i * y^jj
            if mono in monomials and mono not in Mx:
                My += [mono]
    for j in range(degy + 1):
        for i in range(degx + 1):
            mono = x^i * y^j
            if j <= i:
                continue
            if mono in monomials and mono not in Mx and mono not in My:
                My += [mono]
    monomials = Mx + My

    M = Matrix(ZZ, len(monomials))

    # Convert polynomial to vector
    row = 0
    for i in range(mm + 1):
        ii = i
        for k in range(mm + 1):
            for col, monomial in enumerate(monomials):
                M[row, col] = gik[ii, k].monomial_coefficient(monomial) * monomial(XX, YY)
            row += 1
            if ii == 0:
                break
            ii -= 1
    for j in range(1, tt + 1):
        for k in range(mm + 1):
            for col, monomial in enumerate(monomials):
                M[row, col] = hjk[j, k].monomial_coefficient(monomial) * monomial(XX, YY)
            row += 1
            if j == 0:
                break

    matrix_overview(M, modulo^mm)
    # remove unhelpful vectors
    for ii in range(M.nrows() - 1, len(gik.keys()) - 1, -1):
        if M[ii, ii] > modulo^mm:
            M = M[:ii].stack(M[ii+1:])
    '''
    Gaussian Elimination
    M = M.change_ring(QQ)
    for i in range(((mm+1)*(mm+2))/2):
        pivot = M[i, i]
        for j in range(i + 1, M.nrows()):
            if M[j, i] != 0:
                M.add_multiple_of_row(j, i, -(M[j, i]/pivot))
    M = M.change_ring(ZZ)
    '''

    matrix_overview(M)
    B = M.LLL()
    matrix_overview(B)
    Hi = []

    # Generate Polynomials from LLL-reduced Vectors
    for i in range(min(5, B.nrows())):
        # if RR(B[i].norm()) < RR(modulo^mm / sqrt(len(_pol.monomials()))):
        t_pol = 0
        for j, monomial in enumerate(monomials):
            t_pol += ZZ(B[i, j] / monomial(XX, YY)) * monomial
        Hi += [t_pol]

    # Solve Equation for x
    PK = PolynomialRing(ZZ, 'xk')
    xk = PK.gen()
    root_x = root_y = None
    for h1, h2 in itertools.combinations(Hi, 2):
        h = h1.resultant(h2, y).subs(x=xk)
        if not hasattr(h, 'roots'):
            continue
        roots = h.roots()
        if len(roots) == 0:
            continue
        if len(roots) == 1:
            if roots[0][0] != 0:
                root_x = roots[0][0]
                break
        else:
            for r in roots:
                if r[0] != 0:
                    root_x = r[0]
                    break
            if root_x is not None:
                break
    if root_x is None:
        print ('[-] Can\'t find solution for `x`...')
        return None, None

    print ('[+] `x0` = %d' % root_x)

    # Solve Equation for y
    for h in Hi:
        h = h.subs(x=root_x, y=xk)
        if not hasattr(h, 'roots'):
            continue
        roots = h.roots()
        if len(roots) == 0:
            continue
        if len(roots) == 1:
            if roots[0][0] != 0:
                root_y = roots[0][0]
                break
        else:
            for r in roots:
                if r[0] != 0:
                    root_y = r[0]
                    break
            if root_y is not None:
                break
    if root_y is None:
        print ('[-] Can\'t find solution for `y`...')
        return None, None

    print ('[+] `y0` = %d' % root_y)
    return root_x, root_y

def solve_SIP(e, n, delta=0.292, beta=0.5, mm=3):
    F = Zmod(e)
    PR = PolynomialRing(ZZ, 'x, y')
    x, y = PR.gens()
    A = ZZ((n + 1)/2)
    pol = x * (A + y) - 1
    XX = floor(e ^ delta)
    YY = floor(e ^ beta)
    tt = floor((1 - 2 * delta) * mm)
    x0, y0 = boneh_durfee_bivariate(pol, e, XX, YY, mm, tt)
    if x0 is None or y0 is None:
        return None
    assert pol(x0, y0) % e == 0
    d0 = (x0 * (A + y0) - 1) / e
    if (Zmod(n)(2)^e)^d0 == 2:
        return d0
    else:
        return -d0

def main():
    # ASIS CTF Finals 2015: Bodu
    n = 0x3a6160848fb1734cbd0fa22cef582e849223ac04510d51502556b6476d07397f03df155289c20112e87c6f35361d9eb622ca4a0e52d9cd87bf723526c826b88387d06abc4279e353f12ad8ec62ea73c47321a20b89644889a792a73152bc7014b80a693d2e58b123fa925c356b1eba037a4dcac8d8de809167a6fcc30c5c785
    e = 0x365962e8daba7ba92fc08768a5f73b3854f4c79969d5518a078a034437c4669bdb705be4d8b8babf4fda1a6e715269e87b28eecb0d4e02726a27fb8721863740720f583688e5567eb10729bb0d92b322d719949e40c57198d764f1c633e5e277da3d3281ece2ce2eb4df945be5afc3e78498ed0489b2459059664fe15c88a33
    d = solve_SIP(e, n, mm=10, delta=0.28)
    print ('[+] d = %d' % d)


if __name__ == '__main__':
    main()
